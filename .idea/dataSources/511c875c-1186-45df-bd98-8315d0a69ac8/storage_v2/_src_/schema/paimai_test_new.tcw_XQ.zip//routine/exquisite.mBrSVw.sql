create procedure Exquisite()
  BEGIN
	DECLARE adid INT;
	DECLARE npdid INT;
	DECLARE ndid INT;
	DECLARE blid INT;
	declare done int;
	DECLARE ADelayLot CURSOR FOR SELECT l.`id` FROM lot l WHERE l.`auction_id`=
(SELECT MAX(a.`id`) FROM auction a WHERE a.`appr_state`="P" AND a.`valid`=TRUE AND a.`source`="APP" AND a.`bid_model`="AUC_DELAY" AND a.`auction_state`="A")
 AND l.`valid`=TRUE AND l.`archive`=FALSE and l.`source`="APP";

	
	DECLARE NPDelayLot CURSOR FOR SELECT l.`id` FROM lot l WHERE l.`auction_id`=
(SELECT MAX(a.`id`) FROM auction a WHERE a.`appr_state`="P" AND a.`valid`=TRUE AND a.`source`="APP" AND a.`bid_model`="AUC_DELAY" AND a.`auction_state`="N" AND a.`preview`=TRUE)
 AND l.`valid`=TRUE AND l.`archive`=FALSE and l.`source`="APP";

	DECLARE NDelayLot CURSOR FOR SELECT l.`id` FROM lot l WHERE l.`auction_id`=
(SELECT MAX(a.`id`) FROM auction a WHERE a.`appr_state`="P" AND a.`valid`=TRUE AND a.`source`="APP" AND a.`bid_model`="AUC_DELAY" AND a.`auction_state`="N" AND a.`preview`=FALSE)
 AND l.`valid`=TRUE AND l.`archive`=FALSE and l.`source`="APP";

	DECLARE Blot CURSOR FOR SELECT l.`id` FROM lot l  WHERE l.`bid_model`="AUC_BID" and l.`valid`=TRUE AND l.`archive`=FALSE AND l.`source`="APP" GROUP BY l.`auction_state`;
	DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = 1;
	
	OPEN ADelayLot;
	adloop:
	LOOP
		FETCH ADelayLot INTO adid;
		IF done =1 THEN LEAVE adloop;
		END IF;
		IF adid IS NOT NULL THEN 
			UPDATE lot l SET l.`exquisite`=1, l.exq_icon="o_1de43ck2k1uv91tgt1he387icbs4l.jpg" WHERE l.`id`=adid; 
		END IF;
	END LOOP;
	
	SET done=0;
	OPEN NPDelayLot;
	npdloop:
	LOOP
			FETCH NPDelayLot INTO npdid;
			IF done =1 THEN LEAVE npdloop;
					END IF;
			IF npdid IS NOT NULL THEN UPDATE lot l SET l.`exquisite`=TRUE,l.exq_icon="o_1de43ck2k1uv91tgt1he387icbs4l.jpg" WHERE l.`id`=npdid; END IF;
		END LOOP;

	SET done=0;
	OPEN NDelayLot;
	ndloop:
	LOOP
			FETCH NDelayLot INTO ndid;
			IF done =1 THEN LEAVE ndloop;
					END IF;
			IF ndid IS NOT NULL THEN UPDATE lot l SET l.`exquisite`=TRUE,l.exq_icon="o_1de43ck2k1uv91tgt1he387icbs4l.jpg" WHERE l.`id`=ndid; END IF;
		END LOOP;

	SET done=0;
	OPEN Blot;
	bloop:
	LOOP
			FETCH Blot INTO blid;
			IF done =1 THEN LEAVE bloop;
					END IF;
			IF blid IS NOT NULL THEN UPDATE lot l SET l.`exquisite`=TRUE WHERE l.`id`=blid;
			END IF;
		END LOOP;



END;

