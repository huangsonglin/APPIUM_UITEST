create procedure update_observer()
  BEGIN
	#Routine body goes here...
	DECLARE memberId INT;
	DECLARE auction_id INT;
SET auction_id=125058;
	SET memberId=5152;
	WHILE memberId<=5201 DO
	INSERT INTO auction_observer (auction_id, member_id,create_time,created_by,update_by,update_time,version )
VALUES (auction_id, memberId, SYSDATE(), 5152, 5152, SYSDATE(), 1);
	SET memberId=memberId+1;
END WHILE;
UPDATE auction SET observer_count=50 WHERE id=auction_id;



END;

