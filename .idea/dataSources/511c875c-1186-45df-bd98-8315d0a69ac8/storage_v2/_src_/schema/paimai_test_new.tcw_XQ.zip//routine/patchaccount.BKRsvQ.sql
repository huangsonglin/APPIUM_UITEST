create procedure patchAccount()
  BEGIN
    declare done int;
    DECLARE currDate datetime DEFAULT now();#当前时间
    declare memberId int;
    declare withdraw decimal(19,2);
    declare charged decimal(19,2);
    declare refound decimal(19,2);
    declare goodsPay decimal(19,2);
    declare waitWithdraw decimal(19,2);#提现,未完成的
    declare waitCharge decimal(19,2);
    declare buyerWaitAcc decimal(19,2);
    declare sellerWaitAcc decimal(19,2);
    declare accPay decimal(19,2);
    declare balance decimal(19,2);
    declare waitAcc decimal(19,2);
    declare orderId int;
    declare orderNum VARCHAR(255);
    declare payType VARCHAR(255);
    declare payNum VARCHAR(255);
    declare payMoney decimal(19,2);
    declare commission decimal(19,2);#佣金
    declare amount decimal(19,2);#货款
    declare orderStatus VARCHAR(255);
    declare billType VARCHAR(255);
    declare orderReturnId int;
    declare txnNum01 VARCHAR(255);
    DECLARE memberCursor CURSOR FOR SELECT u.`id` FROM `user` u WHERE u.`user_type` = 'F'; #会员游标变量
    DECLARE orderCursor CURSOR FOR SELECT o.`id`, o.`order_num`, o.`pay_type`, o.`pay_num`, o.`pay_money`, o.`hammer_price`-o.`commission`, o.`seller_id`, o.`order_status`, o.`commission`, orr.`id` FROM `order` o LEFT JOIN order_return orr on o.id=orr.order_id; #获取所有订单
    DECLARE financeCursor CURSOR FOR SELECT f.member_id, f.type, f.amount, f.txn_num_01, o.`order_num`, o.`commission` FROM `finance` f left  join `order` o on f.order_id = o.id WHERE f.`appr_state` = 'P' and f.`status` = 'F'; #已完成的财务
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = 1;
    OPEN memberCursor; #打开游标
    # 开始循环
    read_loop:
    LOOP
      FETCH memberCursor INTO memberId;
      IF done = 1 THEN
        LEAVE read_loop;
      END IF;
      #新增两个账户
      INSERT INTO `acc_account` (`create_time`, `update_time`, `created_by`, `update_by`, `version`, `acc_type`, `balance`, `frozen_amount`, `member_id`, `wait_in_amount`, `wait_out_amount`)
      VALUES (currDate, currDate, 1, 1, 0, 'AC', '0.00', '0.00', memberId, '0.00', '0.00');
      INSERT INTO `acc_account` (`create_time`, `update_time`, `created_by`, `update_by`, `version`, `acc_type`, `balance`, `frozen_amount`, `member_id`, `wait_in_amount`, `wait_out_amount`)
      VALUES (currDate, currDate, 1, 1, 0, 'BB', '0.00', '0.00', memberId, '0.00', '0.00');
      #给余额账户初始化数据
      select
        ifnull(sum(case when f.type='W' and f.status='F' then f.amount else 0 end), 0)
        , ifnull(sum(case when f.type='C' and f.status='F' then f.amount else 0 end), 0)
        , ifnull(sum(case when f.type='R' and f.status='F' then f.amount else 0 end), 0)
        , ifnull(sum(case when f.type='P' and f.status='F' then f.amount else 0 end), 0)
        , ifnull(sum(case when f.type='W' and f.status='W' then f.amount else 0 end), 0)
        , ifnull(sum(case when f.type='C' and f.status='W' then f.amount else 0 end), 0)
        , ifnull(sum(case when f.type='R' and f.status='W' then f.amount else 0 end), 0)
        , ifnull(sum(case when f.type='P' and f.status='W' then f.amount else 0 end), 0)
        , ifnull(sum(case when f.type='A' and f.status='F' then f.amount else 0 end), 0)
      into withdraw, charged, refound, goodsPay, waitWithdraw, waitCharge, buyerWaitAcc, sellerWaitAcc, accPay
      from Finance f where f.member_id = memberId;
      #计算各种金额
      set balance = charged + refound + goodsPay - withdraw - accPay; #余额
      set waitAcc = buyerWaitAcc + sellerWaitAcc + waitCharge; #待入账
      #更新余额账户
      update `acc_account` a set a.`balance` = balance, a.`wait_in_amount` = waitAcc, a.`wait_out_amount`=waitWithdraw where a.`acc_type` = 'AC' and a.`member_id` = memberId;
      #插入余额流水
      /*if balance > 0 then
        INSERT INTO `acc_balance_txn` (`create_time`, `update_time`, `created_by`, `update_by`, `version`, `member_id`, `amount`, `other_txn_num`, `self_txn_num`, `source`, `type`)
        VALUES (currDate, currDate, 1, 1, 0, memberId, balance, NULL, 'DCAAC0000000000000000', 'I_YS', 'I');
      end if;*/
    END LOOP;
    close memberCursor;#循环结束后需要关闭游标
    set done = 0;
    #增加支付订单
    OPEN orderCursor;
    read_loop_1:
    LOOP
      FETCH orderCursor INTO orderId, orderNum, payType, payNum, payMoney, amount, memberId, orderStatus, commission, orderReturnId;
      IF done = 1 THEN
        LEAVE read_loop_1;
      END IF;
      if payType IS NOT NULL then #如果支付过订单，则增加流水
        INSERT INTO `order_pay` (`create_time`, `update_time`, `created_by`, `update_by`, `version`, `amount`, `order_id`, `order_num`, `pay_num`, `txn_num`, `pay_type`)
        VALUES (currDate, currDate, 1, 1, 0, payMoney, orderId, orderNum, payNum, 'DCOPY0000000000000000', payType);
      ELSE #如果没有支付过订单，则给卖家增加财务信息
        if orderStatus = 'C' THEN #如果直接取消订单，则将财务信息设置为已完成/审批不通过
          INSERT INTO `finance` (`create_time`, `update_time`, `version`, `created_by`, `update_by`,`amount`, `status`, `type`,  `member_id`, `appr_state`, `order_id`, `reject_reason`, `remark`)
          VALUES (currDate, currDate, '0', '1', '1', amount, 'F', 'P', memberId, 'F', orderId, '订单被取消', '协商取消订单，不扣除保证金');
        else
          INSERT INTO `finance` (`create_time`, `update_time`, `version`, `created_by`, `update_by`,`amount`, `status`, `type`,  `member_id`, `appr_state`, `order_id`)
          VALUES (currDate, currDate, '0', '1', '1', amount, 'W', 'P', memberId, 'W', orderId);
        END IF;
      end IF;
      #如果是退款订单，
      if payType IS NOT NULL and orderStatus = 'C' then
        if orderId = 232 THEN #指定订单id，该订单不退还佣金
          #插入用户退款订单数据
          INSERT INTO `order_return_pay` (`create_time`, `update_time`, `version`, `created_by`, `update_by`, `amount`, `order_return_id`, `pay_num`, `pay_type`, `remark`, `txn_num`)
          VALUES (currDate, currDate, '0', '1', '1', amount, orderReturnId, 'DCAAC0000000000000000', 'AC', NULL, 'DCORF0000000000000000');
        ELSE
          #插入用户退款订单数据
          INSERT INTO `order_return_pay` (`create_time`, `update_time`, `version`, `created_by`, `update_by`, `amount`, `order_return_id`, `pay_num`, `pay_type`, `remark`, `txn_num`)
          VALUES (currDate, currDate, '0', '1', '1', amount, orderReturnId, 'DCAAC0000000000000000', 'AC', NULL, 'DCORF0000000000000000');
          if commission > 0 then
            #插入公账退款订单数据
            INSERT INTO `order_return_pay` (`create_time`, `update_time`, `version`, `created_by`, `update_by`, `amount`, `order_return_id`, `pay_num`, `pay_type`, `remark`, `txn_num`)
            VALUES (currDate, currDate, '0', '1', '1', commission, orderReturnId, 'DCCCP0000000000000000', 'CM', NULL, 'DCORF0000000000000000');
            #插入公账流水
            INSERT INTO `acc_comp_txn` (`create_time`, `update_time`, `version`, `created_by`, `update_by`, `amount`, `other_txn_num`, `self_txn_num`, `source`, `type`)
            VALUES (currDate, currDate, '0', '1', '1', commission, 'DCORF0000000000000000', 'DCCCP0000000000000000', 'O_CM', 'O');
          END IF;
        END IF;
      END IF;
    END LOOP;
    close orderCursor;
    #更新所有的支付类型A->AL, F->OF
    UPDATE `order_pay` op set op.pay_type = 'AL' where op.pay_type = 'A';
    UPDATE `order_pay` op set op.pay_type = 'OF' where op.pay_type = 'F';
    set done = 0;
    #增加公账流水
    OPEN financeCursor;
    read_loop:
    LOOP
      FETCH financeCursor INTO memberId, billType, amount, txnNum01, orderNum, commission;
      IF done = 1 THEN
        LEAVE read_loop;
      END IF;
      if billType = 'C' THEN #充值（会员）
        INSERT INTO `acc_balance_txn` (`create_time`, `update_time`, `version`, `created_by`, `update_by`, `member_id`, `amount`, `other_txn_num`, `self_txn_num`, `source`, `type`)
        VALUES (currDate, currDate, '0', '1', '1', memberId, amount, txnNum01, 'DCAAC0000000000000', 'I_OF', 'I');
      ELSEIF billType = 'W' THEN #提现（会员）
        INSERT INTO `acc_balance_txn` (`create_time`, `update_time`, `version`, `created_by`, `update_by`, `member_id`, `amount`, `other_txn_num`, `self_txn_num`, `source`, `type`)
        VALUES (currDate, currDate, '0', '1', '1', memberId, amount, txnNum01, 'DCAAC0000000000000', 'O_WD', 'O');
      ELSEIF billType = 'R' THEN #退款（买家）
        INSERT INTO `acc_balance_txn` (`create_time`, `update_time`, `version`, `created_by`, `update_by`, `member_id`, `amount`, `other_txn_num`, `self_txn_num`, `source`, `type`)
        VALUES (currDate, currDate, '0', '1', '1', memberId, amount, orderNum, 'DCAAC0000000000000', 'I_RF', 'I');
      ELSEIF billType = 'P' THEN #货款（卖家）
        INSERT INTO `acc_balance_txn` (`create_time`, `update_time`, `version`, `created_by`, `update_by`, `member_id`, `amount`, `other_txn_num`, `self_txn_num`, `source`, `type`)
        VALUES (currDate, currDate, '0', '1', '1', memberId, amount, orderNum, 'DCAAC0000000000000', 'I_GP', 'I');
        if commission > 0 then
          INSERT INTO `acc_comp_txn` (`create_time`, `update_time`, `created_by`, `update_by`, `version`, `amount`, `other_txn_num`, `self_txn_num`, `source`, `type`)
          VALUES (currDate, currDate, 1, 1, 0, commission, orderNum, 'DCCCP0000000000000000', 'I_CM', 'I');
        END IF;
      ELSE #A 账户支付(只能支付退款订单)（卖家）
        INSERT INTO `acc_balance_txn` (`create_time`, `update_time`, `version`, `created_by`, `update_by`, `member_id`, `amount`, `other_txn_num`, `self_txn_num`, `source`, `type`)
        VALUES (currDate, currDate, '0', '1', '1', memberId, amount, orderNum, 'DCAAC0000000000000', 'O_RF', 'O');
      END IF;
    END LOOP;
    close financeCursor;
  END;

