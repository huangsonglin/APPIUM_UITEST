create procedure jipai()
  BEGIN
		DECLARE A_auction decimal(10, 2);
		DECLARE N_auction decimal(10, 2);
		DECLARE F_auction decimal(10, 2);
		DECLARE max_sort decimal(10, 2);
		DECLARE v_name VARCHAR(255);
		DECLARE aid decimal(10, 2);
		
SELECT MAX(id) INTO A_auction from auction WHERE auction_state IN ("A","S","P") AND valid=TRUE AND appr_state="P" AND auction_group=FALSE;
SELECT MAX(id) INTO N_auction from auction WHERE auction_state="N" AND valid=TRUE AND appr_state="P" AND auction_group=FALSE;
SELECT MAX(id) INTO F_auction from auction WHERE auction_state="F" AND valid=TRUE AND appr_state="P" AND auction_group=FALSE;
SELECT MAX(sort)+1 INTO max_sort FROM auction_group_info;
SELECT DATE_FORMAT(CURDATE(),"%Y-%m-%d") INTO v_name;

# 新建一个正在进行中的季拍合集 
INSERT INTO auction_group_info (icon, title, review, type,state,sort,valid,created_by,create_time,update_by,update_time,version) 
VALUES("996495AF-9433-41BD-948C-FEEA4D3E9CE62.JPG", CONCAT(v_name,"季拍合集测试集合"), 1, "AUCTION", 'STARTED', max_sort+1, 1, 5152, SYSDATE(), 5152, SYSDATE(), 1);


# 新建后的季拍id
SELECT MAX(id) INTO aid FROM auction_group_info; 

# 季拍合集中添加拍场
IF A_auction IS NOT NULL THEN
INSERT INTO auction_group (auction_group_info_id, auction_id, live_id, type, sort, valid, created_by, create_time, update_by, update_time, version) VALUES 
(aid, A_auction, 1, "AUCTION", 7, 1, 5152, SYSDATE(), 5152, SYSDATE(), 1);
END IF;

IF N_auction IS NOT NULL THEN 
INSERT INTO auction_group (auction_group_info_id, auction_id, live_id, type, sort, valid, created_by, create_time, update_by, update_time, version) VALUES 
(aid, N_auction, 1, "AUCTION", 7, 1, 5152, SYSDATE(), 5152, SYSDATE(), 1);
END IF;

IF F_auction IS NOT NULL THEN 
INSERT INTO auction_group (auction_group_info_id, auction_id, live_id, type, sort, valid, created_by, create_time, update_by, update_time, version) VALUES 
(aid, F_auction, 1, "AUCTION", 7, 1, 5152, SYSDATE(), 5152, SYSDATE(), 1);
END IF;

# 更新auction
UPDATE auction SET auction_group=1, auction_group_info_id=aid WHERE id IN(A_auction, F_auction, N_auction);


END;

