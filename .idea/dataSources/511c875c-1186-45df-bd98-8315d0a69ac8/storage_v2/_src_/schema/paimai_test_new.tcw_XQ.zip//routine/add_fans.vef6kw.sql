create procedure add_fans(IN memberId int)
  BEGIN
	DECLARE fid BIGINT(20) DEFAULT 5152;
	DECLARE i INT DEFAULT 1;
	
	WHILE i <= 50 DO
		# INSERT INTO fans (create_time, update_time, version, created_by, update_by, fans_id, member_id) VALUES (SYSDATE(), SYSDATE(), 1, `memberId`, `memberId`, fid, `memberId`);
		INSERT INTO `fans` (`create_time`, `update_time`, `version`, `created_by`, `update_by`, `fans_id`, `member_id`) VALUES ( SYSDATE(), SYSDATE(), 1, `memberId`, `memberId`, fid, `memberId`);
		SET i = i +1;
		SET fid = fid + 1;
		
	END WHILE;

END;

